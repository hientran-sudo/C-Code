﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory
{
    internal class World
    {
        private Southern _south;
        private Northern _north;

        public World(ContinentFactory factory)
        {
            _south = factory.CreateSoutheastCountries();
            _north = factory.CreateNorthernCountries();
        }
        public void ShowRelationship()
        {
            _south.Relationship(_north);
        }
    }
}
