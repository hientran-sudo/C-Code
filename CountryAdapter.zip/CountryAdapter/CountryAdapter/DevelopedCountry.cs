﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountryAdapter
{
    internal class DevelopedCountry : Country
    {
        private string name;
        private DataBank bank;
        public DevelopedCountry(string name)
        {
            this.name = name;
        }
        public override void Display()
        {
            bank = new DataBank();
            continent = bank.GetContinent(name);
            language = bank.GetLang(name);

            Console.WriteLine("\nCountry: {0} ------ ", name);
            Console.WriteLine("\nContinent: {0} ------ ", continent);
            Console.WriteLine("\nLanguage: {0} ------ ", language);

        }
    }
    
}
