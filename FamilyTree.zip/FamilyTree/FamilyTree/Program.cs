﻿namespace FamilyTree
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Branch root = new Branch("root");
            root.Add(new Leaf("Adam"));
            root.Add(new Leaf("Lily"));
            root.Add(new Leaf("Davis"));

            Branch adam = new Branch("Adam's");
            adam.Add(new Leaf("Adam's son 1 - Jose"));
            adam.Add(new Leaf("Adam's son 2 - Jack"));

            Branch lily = new Branch("Lily's");
            lily.Add(new Leaf("Lily's son 1 - Matt"));
            lily.Add(new Leaf("Lily's daughter - Sandy"));

            Branch matt = new Branch("Matt's");
            matt.Add(new Leaf("Matt's daughter - Kim"));


            root.Add(adam);
            root.Add(lily);
            lily.Add(matt);
            root.Display(1);
            Console.ReadKey();
        }


    }
}
