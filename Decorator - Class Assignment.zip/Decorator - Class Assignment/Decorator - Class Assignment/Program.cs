﻿using SWEG_lab;

Acoustic acoustic = new Acoustic("Acoustic guitar", 500);
Bass bass = new Bass("Bass guitar", 600);
Electric electric = new Electric("Electric guitar", 700);

Console.WriteLine(acoustic);

GuitarDecorator guitarDecorator = new GuitarDecorator(acoustic, "Magenta", 50);

Console.WriteLine(guitarDecorator);

