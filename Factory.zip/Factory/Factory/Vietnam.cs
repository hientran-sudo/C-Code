﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory
{
    internal class Vietnam : Southern
    {
        public override void Relationship(Northern north)
        {
            Console.WriteLine(this.GetType().Name + " and " + north.GetType().Name + " share the border");
        }
    }
}
