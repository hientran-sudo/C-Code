﻿using System.Text;
using System.Threading.Tasks;

namespace CountryAdapter
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Create adapter and place a request
            Country country = new Country();
            country.Display();
            Country vn = new DevelopedCountry("Vietnam");
            vn.Display();

            Country us = new DevelopedCountry("USA");
            us.Display();
            // Wait for user
            Console.ReadKey();
        }

    }
    
}

