﻿using System;
namespace Factory
{
    class Program
    {
        public static void Main()
        {
            
            ContinentFactory europe = new EuropeFactory();
            World world = new World(europe);
            world.ShowRelationship();

            ContinentFactory asia = new AsiaFactory();
            world = new World(asia);
            world.ShowRelationship();

            Console.ReadKey();
        }
    }
}
