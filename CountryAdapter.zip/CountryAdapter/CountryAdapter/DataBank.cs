﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountryAdapter
{
    internal class DataBank
    {
        public string GetContinent(string country)
        {
            switch (country)
            {
                case "Vietnam":
                    return "Asia";
                case "Thailand":
                    return "Asia";
                case "USA":
                    return "America";
                default: return "N/a";
            }
        }

        public string GetLang(string country)
        {
            switch (country)
            {
                case "Vietnam":
                    return "Vietnamese";
                case "Thailand":
                    return "Thai";
                case "USA":
                    return "English";
                default: return "N/a";
            }

        }

    }
}
