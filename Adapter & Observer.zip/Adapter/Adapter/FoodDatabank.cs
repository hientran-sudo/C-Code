﻿namespace Adapter
{
    public class FoodDatabank
    {
        public double getLevles(Food food, String choice)
        {
            if (choice.Equals("C"))
            {
                if (food.Name.Equals("water"))
                    { return 0.0; }
                else if (food.Name.Equals("beef"))
                    { return 450.0; }
                else if (food.Name.Equals("chicken"))
                    { return 250.0; }
                else
                    { return 0.0; }
            }
            else
            {
                if (food.Name.Equals("water"))
                    { return 0.0; }
                else if (food.Name.Equals("beef"))
                    { return 80.0; }
                else if (food.Name.Equals("chicken"))
                    { return 40.0; }
                else
                    { return 0.0; }
            }
        }

        public String getServingSize(Food food)
        {
            if (food.Name.Equals("water"))
                { return "1 liter"; }
            else if (food.Name.Equals("beef"))
                { return "12 oz"; }
            else if (food.Name.Equals("chicken"))
                { return "12 oz"; }
            else
                { return "0"; }
        }

        public float GetCholesterolLevel(Food food)
        {
            if (food.Name.Equals("water"))
                { return 0; }
            else if (food.Name.Equals("beef"))
                { return 22; }
            else if (food.Name.Equals("chicken"))
                { return 38; }
            else
                { return 0; }
        }
    }
}