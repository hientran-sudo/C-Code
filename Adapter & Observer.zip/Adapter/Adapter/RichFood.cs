﻿namespace Adapter
{
    /***
     * 
     * The adapter class
     * 
    ***/
    public class RichFood : Food
    {       
        private readonly FoodDatabank bank;

        public RichFood(String n)
        {
            Name = n;
            bank = new FoodDatabank();
        }

        public String Display()
        {
            return "Name : " + Name + "\n"
                        + " calories: " + bank.getLevles(this, "C") + "\n"
                        + " Sodium: " + bank.getLevles(this, "S") + " grams" + "\n"
                        + " Cholesterol: " + bank.GetCholesterolLevel(this) + "%" + "\n"
                        + " Serving Size: " + bank.getServingSize(this) + "\n";
        }
    }
}
