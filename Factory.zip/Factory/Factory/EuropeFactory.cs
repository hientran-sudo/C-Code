﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory
{
    internal class EuropeFactory : ContinentFactory
    {
        public override Northern CreateNorthernCountries()
        {
            return new Finland();
        }
        public override Southern CreateSoutheastCountries()
        {
            return new France();
        }
    }
}
