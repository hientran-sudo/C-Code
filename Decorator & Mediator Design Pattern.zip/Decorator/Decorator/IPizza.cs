﻿namespace Decorator
{
    public interface Pizza
    {
        string MakePizza();
    }
}
