﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountryAdapter
{
    internal class Country
    {
        protected string continent;
        protected string language;
        public virtual void Display()
        {
            Console.WriteLine("Country List");
        }
    }
    
}
