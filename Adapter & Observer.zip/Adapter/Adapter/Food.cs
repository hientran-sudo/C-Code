﻿/**
 * This is the target interface
 */

namespace Adapter
{
    public class Food
    {
        public String Name { get; set; }

        public String Display()
        {
            String s = "Name: " + Name;
            return s;
        }
    }
}
