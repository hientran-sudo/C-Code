﻿
namespace SWEG_lab
{
    public abstract class BaseGuitar
    {
        private readonly string _name;
        private readonly double _price;

        protected BaseGuitar(string Name, double Price)
        {
            _name = Name;
            _price = Price;
        }

        public string GetName()
        {
            return _name;
        }

        public virtual double GetPrice()
        {
            return _price;
        }

        public override string ToString()
        {
            return string.Format("Name: {0}, Price: {1:C}", _name, _price);
        }
    }
}
