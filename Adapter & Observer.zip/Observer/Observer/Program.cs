﻿namespace Observer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Headquarters headquarters = new Headquarters("Headquarters");
            Inspector inspector1 = new Inspector("Greg Lestrade");
            Inspector inspector2 = new Inspector("Sherlock Holmes");

            inspector1.Assign(headquarters);
            inspector2.Assign(headquarters);

            headquarters.SendMessage(new Message("Catch Moriarty!"));

            inspector2.SendMessage(new Message("Moriarty has been arrested!"));

            headquarters.EndTransmission();

            Console.ReadKey();
        }
    }
}