﻿namespace Mediator
{    public class ConcreteUser : User
    {
        public ConcreteUser(IFacebookGroupMediator mediator, string name) : base(mediator, name)
        {
        }

        public override void Receive(string message)
        {
            Console.WriteLine(this.name + ":\tReceived Message:  " + message);
        }

        public override void Send(string message)
        {
            Console.WriteLine(this.name + ":\tSending Message:  " + message + "\n");
            mediator.SendMessage(message, this);
        }
    }
}
