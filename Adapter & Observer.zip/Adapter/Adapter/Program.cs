﻿namespace Adapter {
    public class Client
    {
        public static void Main()
        {
            Food water = new RichFood("water");
            Food beef = new RichFood("beef");
            Food chicken = new RichFood("chicken");
            Food moonrocks = new RichFood("moon rocks");

            Console.WriteLine(water.Display());
            Console.WriteLine(beef.Display());
            Console.WriteLine(chicken.Display());
            Console.WriteLine(moonrocks.Display());
        }
    }
}