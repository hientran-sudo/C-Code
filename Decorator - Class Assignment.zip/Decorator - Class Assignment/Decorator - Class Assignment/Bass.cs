﻿namespace SWEG_lab
{
    public class Bass : BaseGuitar
    {
        public Bass(string Name, double Price) : base(Name, Price) { }
    }
}
