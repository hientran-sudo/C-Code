﻿namespace SWEG_lab
{
    public class GuitarDecorator : BaseGuitar
    {
        private readonly BaseGuitar _guitar;
        private readonly double _priceIncrease;

        public GuitarDecorator(BaseGuitar baseGuitar, double PriceIncrease) : base(baseGuitar.GetName(), baseGuitar.GetPrice()) { 
            _guitar = baseGuitar;
            _priceIncrease = PriceIncrease;
        }

        public override double GetPrice()
        {
            return base.GetPrice() + _priceIncrease;
        }

        public override string ToString()
        {
            return string.Format("Name: {0}, Price: {1:C}", _guitar.GetName(), this.GetPrice());
        }
    }
}
