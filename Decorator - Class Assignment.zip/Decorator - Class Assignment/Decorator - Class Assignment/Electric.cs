﻿namespace SWEG_lab
{
    public class Electric : BaseGuitar
    {
        public Electric(string Name, double Price) : base(Name, Price) { }
    }
}
